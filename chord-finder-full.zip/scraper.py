import requests
from bs4 import BeautifulSoup

def fetch_chords_ug(song_title):
    url = f"https://www.ultimate-guitar.com/search.php?search_type=title&value={song_title}"
    resp = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'})
    soup = BeautifulSoup(resp.text, 'html.parser')
    link = soup.select_one('a.js-store')
    if link:
        page = requests.get(link['href'], headers={'User-Agent': 'Mozilla/5.0'})
        page_soup = BeautifulSoup(page.text, 'html.parser')
        chords = page_soup.select_one('div.js-tab-content')
        if chords:
            return chords.get_text(separator='\n').strip()
    return None