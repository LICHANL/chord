from flask import Flask, render_template, redirect, url_for, request, flash
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User, CustomChord
from scraper import fetch_chords_ug

app = Flask(__name__)
app.config['SECRET_KEY'] = 'replace-with-secret'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'
db.init_app(app)

login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.before_first_request
def create_tables():
    db.create_all()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search', methods=['POST'])
@login_required
def search():
    song = request.form['song'].strip()
    custom = CustomChord.query.filter_by(title=song, owner=current_user).first()
    chords = custom.progression if custom else fetch_chords_ug(song)
    if not chords:
        flash('Chord progression not found.')
    return render_template('index.html', song=song, chords=chords)

@app.route('/upload', methods=['GET','POST'])
@login_required
def upload():
    if request.method == 'POST':
        title = request.form['title'].strip()
        progression = request.form['progression'].strip()
        if title and progression:
            custom = CustomChord(title=title, progression=progression, owner=current_user)
            db.session.add(custom); db.session.commit()
            flash("Saved custom chords!")
            return redirect(url_for('index'))
    return render_template('upload.html')

@app.route('/signup', methods=['GET','POST'])
def signup():
    if request.method == 'POST':
        uname = request.form['username']; pw = request.form['password']
        if User.query.filter_by(username=uname).first():
            flash("Username exists.")
        else:
            u = User(username=uname, password=generate_password_hash(pw))
            db.session.add(u); db.session.commit()
            flash("Account created. Please log in.")
            return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        u = User.query.filter_by(username=request.form['username']).first()
        if u and check_password_hash(u.password, request.form['password']):
            login_user(u); flash("Logged in.")
            return redirect(url_for('index'))
        flash("Invalid credentials.")
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash("Logged out.")
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)